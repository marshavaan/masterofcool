# MasterOfCool Website

A professional, responsive website for MasterOfCool - Expert aircon servicing, chemical cleaning, and HVAC maintenance in Singapore.

## Features

- **Fully Responsive Design**: Works seamlessly on desktop, tablet, and mobile devices
- **Modern UI/UX**: Clean, professional design with smooth animations and transitions
- **SEO Optimized**: Proper meta tags and semantic HTML structure
- **No External Dependencies**: Pure HTML, CSS, and JavaScript - no frameworks required
- **Fast Loading**: Optimized code with no images for maximum performance

## Pages Included

1. **Home (index.html)**: Features a comprehensive 1500+ word article about aircon cooling issues
2. **About (about.html)**: Company information, mission, and services overview
3. **Contact (contact.html)**: Contact form and business information
4. **Privacy Policy (privacy.html)**: Complete privacy policy documentation

## File Structure

```
masterofcool-website/
├── index.html          # Homepage with featured article
├── about.html          # About page
├── contact.html        # Contact page
├── privacy.html        # Privacy policy page
├── style.css           # Main stylesheet
├── script.js           # JavaScript functionality
└── README.md           # This file
```

## Deployment Instructions

### Option 1: Deploy to Deno Deploy via GitHub

1. **Create a GitHub Repository**
   - Go to GitHub and create a new repository
   - Name it something like `masterofcool-website`

2. **Upload Files to GitHub**
   - Upload all files from the `masterofcool-website` folder to your repository
   - Make sure all files are in the root directory of the repository

3. **Connect to Deno Deploy**
   - Go to [dash.deno.com](https://dash.deno.com)
   - Sign in with your GitHub account
   - Click "New Project"
   - Select your GitHub repository
   - Choose "Automatic" deployment mode
   - Deploy!

### Option 2: Deploy to Other Platforms

The website is compatible with:
- **Vercel**: Connect GitHub repo and deploy
- **Netlify**: Drag and drop the folder or connect via GitHub
- **GitHub Pages**: Enable in repository settings
- **Any Static Hosting**: Upload files via FTP/SFTP

## Technical Details

- **HTML5**: Semantic markup with proper accessibility
- **CSS3**: Modern styling with CSS Grid and Flexbox
- **Vanilla JavaScript**: No dependencies, pure ES6+
- **Mobile-First**: Responsive design with breakpoints at 768px and 480px

## Browser Compatibility

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
- Mobile browsers (iOS Safari, Chrome Mobile)

## Customization

To customize the website:

1. **Colors**: Edit CSS variables in `style.css` (lines 9-21)
2. **Content**: Edit HTML files directly
3. **Styling**: Modify `style.css`
4. **Functionality**: Update `script.js`

## Performance

- **No Images**: Design uses CSS gradients and colors only
- **Minimal CSS**: ~14KB minified
- **Lightweight JS**: ~5KB minified
- **Fast Load Time**: < 1 second on average connection

## Support

For questions or issues, please refer to the contact information on the website.

## License

© 2025 MasterOfCool. All rights reserved.
